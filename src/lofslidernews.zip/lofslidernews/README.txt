

+ The plugin is released under MIT and  GPL V2 and Later.
+ LandOfCoder Allow you use it on all of your free projects and commercial productst, and does not require you putting the credited link.
+ We Do not allow you remove any copyright in javascript files.
+ LandOfCoder offer possibilities for developers to create modules ,
  themes to plug and play with this. And you send us yours via email landofcoder@gmail.com , we will publish them for free download on our site.

More Information: http://landofcoder.com/jquery-plugins/lof-jslidernew-plugin.html
Support: http://landofcoder.com/help-desk.html